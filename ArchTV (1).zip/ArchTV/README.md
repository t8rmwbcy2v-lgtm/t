# Arch TV
A simple, ad-free Android TV launcher. No AI, no tracking, no recommendations row.
- Full-screen scenic photos that crossfade (daily Bing pictures, cached on device)
- Clock, date and a weather widget (nearest city found from your IP; Open-Meteo)
- Bottom app row, with pin / hide / uninstall on long-press
- Own settings screen (gear, top right)
- Optional Home button override via an Accessibility service
