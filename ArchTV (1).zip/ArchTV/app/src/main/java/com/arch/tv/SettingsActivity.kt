package com.arch.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Row(val title: String, val value: () -> String, val onClick: () -> Unit)

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var adapter: SettingsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)

        adapter = SettingsAdapter(buildRows())
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged() // e.g. back from Accessibility settings
    }

    private fun onOff(b: Boolean) = if (b) "On" else "Off"

    private fun buildRows(): List<Row> = listOf(
        Row("Background", { if (prefs.natureBg) "Nature photos" else "Solid colour" }) {
            prefs.natureBg = !prefs.natureBg
        },
        Row("Change photo every", { Prefs.INTERVAL_LABELS[prefs.intervalIdx] }) {
            prefs.intervalIdx = (prefs.intervalIdx + 1) % Prefs.INTERVAL_LABELS.size
        },
        Row("Background dimming", { "${prefs.dim}%" }) {
            prefs.dim = if (prefs.dim >= 70) 0 else prefs.dim + 10
        },
        Row("Weather widget", { onOff(prefs.weatherOn) }) {
            prefs.weatherOn = !prefs.weatherOn
        },
        Row("Temperature unit", { if (prefs.fahrenheit) "Fahrenheit (°F)" else "Celsius (°C)" }) {
            prefs.fahrenheit = !prefs.fahrenheit
        },
        Row("Clock", { if (prefs.clock24) "24-hour" else "12-hour" }) {
            prefs.clock24 = !prefs.clock24
        },
        Row("Show date", { onOff(prefs.showDate) }) {
            prefs.showDate = !prefs.showDate
        },
        Row("App order", { if (prefs.newestFirst) "Newest first" else "A to Z" }) {
            prefs.newestFirst = !prefs.newestFirst
        },
        Row("App names", { if (prefs.labelsOnFocus) "Only when selected" else "Always shown" }) {
            prefs.labelsOnFocus = !prefs.labelsOnFocus
        },
        Row("Icon size", { arrayOf("Small", "Medium", "Large")[prefs.iconSize.coerceIn(0, 2)] }) {
            prefs.iconSize = (prefs.iconSize + 1) % 3
        },
        Row("Hidden apps", { "${prefs.hidden.size} hidden" }) {
            showHiddenDialog()
        },
        Row("Home button override", {
            when {
                !prefs.homeOverride -> "Off"
                serviceEnabled() -> "On"
                else -> "Needs permission"
            }
        }) {
            if (prefs.homeOverride && serviceEnabled()) {
                prefs.homeOverride = false
            } else {
                prefs.homeOverride = true
                if (!serviceEnabled()) showAccessibilityHelp()
            }
        },
        Row("System settings", { "Open" }) {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    )

    private fun serviceEnabled(): Boolean {
        val me = ComponentName(this, HomeKeyService::class.java)
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun showAccessibilityHelp() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Turn on Home button override")
            .setMessage(
                "Google TV sends the Home button to Google's launcher. To catch it, switch Arch TV on " +
                    "in Accessibility.\n\n" +
                    "Settings > Accessibility > Arch TV > On\n\n" +
                    "If the switch is greyed out, go to Settings > Apps > See all apps > Arch TV, open " +
                    "the menu and choose \"Allow restricted settings\", then try again.\n\n" +
                    "To undo it any time, switch Arch TV off in the same place."
            )
            .setPositiveButton("Open Accessibility") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun showHiddenDialog() {
        val apps = AppRepo.queryAll(this).sortedBy { it.label.lowercase() }
        val hidden = prefs.hidden.toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in hidden }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Tick the apps to hide from home")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                if (isChecked) hidden.add(apps[i].pkg) else hidden.remove(apps[i].pkg)
            }
            .setPositiveButton("Done") { _, _ ->
                prefs.hidden = hidden
                adapter.notifyDataSetChanged()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

class SettingsAdapter(private val rows: List<Row>) : RecyclerView.Adapter<SettingsAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val value: TextView = view.findViewById(R.id.value)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_setting, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]
        holder.title.text = row.title
        holder.value.text = row.value()
        holder.itemView.setOnClickListener {
            row.onClick()
            notifyItemChanged(holder.bindingAdapterPosition)
        }
    }

    override fun getItemCount() = rows.size
}
