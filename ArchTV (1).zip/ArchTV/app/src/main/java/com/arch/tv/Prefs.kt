package com.arch.tv

import android.content.Context

/** All Arch TV settings live here. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("archtv", Context.MODE_PRIVATE)

    private fun getBool(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun getInt(k: String, d: Int) = sp.getInt(k, d)
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var natureBg: Boolean
        get() = getBool("nature_bg", true)
        set(v) = putBool("nature_bg", v)

    var intervalIdx: Int
        get() = getInt("interval_idx", 2).coerceIn(0, INTERVALS_MS.size - 1)
        set(v) = putInt("interval_idx", v)

    var dim: Int
        get() = getInt("dim", 20)
        set(v) = putInt("dim", v)

    var weatherOn: Boolean
        get() = getBool("weather_on", true)
        set(v) = putBool("weather_on", v)

    var fahrenheit: Boolean
        get() = getBool("fahrenheit", false)
        set(v) = putBool("fahrenheit", v)

    var clock24: Boolean
        get() = getBool("clock24", false)
        set(v) = putBool("clock24", v)

    var showDate: Boolean
        get() = getBool("show_date", true)
        set(v) = putBool("show_date", v)

    var newestFirst: Boolean
        get() = getBool("newest_first", false)
        set(v) = putBool("newest_first", v)

    var labelsOnFocus: Boolean
        get() = getBool("labels_on_focus", false)
        set(v) = putBool("labels_on_focus", v)

    var iconSize: Int
        get() = getInt("icon_size", 1)
        set(v) = putInt("icon_size", v)

    var homeOverride: Boolean
        get() = getBool("home_override", true)
        set(v) = putBool("home_override", v)

    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet("hidden", HashSet(v)).apply()

    var pinned: List<String>
        get() = (sp.getString("pinned", "") ?: "").split(",").filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("pinned", v.joinToString(",")).apply()

    // ---- caches (not user-facing settings) ----
    var locLat: String?
        get() = sp.getString("loc_lat", null)
        set(v) = sp.edit().putString("loc_lat", v).apply()

    var locLon: String?
        get() = sp.getString("loc_lon", null)
        set(v) = sp.edit().putString("loc_lon", v).apply()

    var locCity: String?
        get() = sp.getString("loc_city", null)
        set(v) = sp.edit().putString("loc_city", v).apply()

    var locTime: Long
        get() = sp.getLong("loc_time", 0L)
        set(v) = sp.edit().putLong("loc_time", v).apply()

    var bgUrls: String
        get() = sp.getString("bg_urls", "") ?: ""
        set(v) = sp.edit().putString("bg_urls", v).apply()

    var bgUrlsTime: Long
        get() = sp.getLong("bg_urls_time", 0L)
        set(v) = sp.edit().putLong("bg_urls_time", v).apply()

    val intervalMs: Long get() = INTERVALS_MS[intervalIdx]

    companion object {
        val INTERVALS_MS = longArrayOf(15_000, 30_000, 60_000, 300_000, 900_000)
        val INTERVAL_LABELS = arrayOf("15 seconds", "30 seconds", "1 minute", "5 minutes", "15 minutes")
    }
}
