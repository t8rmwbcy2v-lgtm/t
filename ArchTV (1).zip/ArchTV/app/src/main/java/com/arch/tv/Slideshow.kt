package com.arch.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Cycles scenic wallpaper photos behind the home screen with a slow crossfade.
 * Photos come from Bing's daily picture archive (no account or key needed) and are
 * cached on the device, so they load instantly and still work if the internet drops.
 */
class Slideshow(
    ctx: Context,
    private val old: ImageView,
    private val new: ImageView,
    private val prefs: Prefs
) {
    private val app = ctx.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val dir = File(app.cacheDir, "bg").apply { mkdirs() }

    private var urls: List<String> = emptyList()
    private var idx = 0
    private var gen = 0
    private var fails = 0
    private var running = false

    fun start() {
        if (running) return
        running = true
        val g = ++gen
        io.execute {
            val list = loadUrls()
            handler.post {
                if (g == gen) {
                    urls = list
                    step(g)
                }
            }
        }
    }

    fun stop(clear: Boolean = false) {
        running = false
        gen++
        handler.removeCallbacksAndMessages(null)
        new.animate().cancel()
        if (clear) {
            old.setImageDrawable(null)
            new.setImageDrawable(null)
            new.alpha = 0f
        }
    }

    private fun step(g: Int) {
        if (g != gen) return
        if (urls.isEmpty()) {
            // nothing yet (probably offline): try the whole thing again in a bit
            handler.postDelayed({
                if (g == gen) {
                    running = false
                    start()
                }
            }, 30_000)
            return
        }
        val url = urls[idx++ % urls.size]
        io.execute {
            val bmp = loadBitmap(url)
            handler.post {
                if (g != gen) return@post
                if (bmp != null) {
                    fails = 0
                    show(bmp)
                    handler.postDelayed({ step(g) }, prefs.intervalMs)
                } else {
                    fails++
                    val wait = if (fails >= urls.size) 60_000L else 3_000L
                    handler.postDelayed({ step(g) }, wait)
                }
            }
        }
    }

    private fun show(bmp: Bitmap) {
        new.setImageBitmap(bmp)
        new.alpha = 0f
        new.visibility = View.VISIBLE
        new.animate().alpha(1f).setDuration(1500).withEndAction {
            old.setImageBitmap(bmp)
            new.alpha = 0f
        }.start()
    }

    // ---------- photo list ----------

    private fun loadUrls(): List<String> {
        val now = System.currentTimeMillis()
        val cached = prefs.bgUrls.split("\n").filter { it.startsWith("http") }
        if (cached.isNotEmpty() && now - prefs.bgUrlsTime < 12 * 3_600_000L) {
            return cached.shuffled()
        }
        val fresh = fetchBing()
        if (fresh.isNotEmpty()) {
            val merged = (fresh + cached).distinct().take(40)
            prefs.bgUrls = merged.joinToString("\n")
            prefs.bgUrlsTime = now
            return merged.shuffled()
        }
        return cached.shuffled()
    }

    private fun fetchBing(): List<String> {
        val out = ArrayList<String>()
        for (start in intArrayOf(0, 8)) {
            val body = Net.get("https://www.bing.com/HPImageArchive.aspx?format=js&idx=$start&n=8&mkt=en-US")
                ?: continue
            try {
                val arr = JSONObject(body).getJSONArray("images")
                for (i in 0 until arr.length()) {
                    val u = arr.getJSONObject(i).optString("url", "")
                    if (u.isNotEmpty()) out += if (u.startsWith("http")) u else "https://www.bing.com$u"
                }
            } catch (_: Exception) {
            }
        }
        return out
    }

    // ---------- loading + caching ----------

    private fun loadBitmap(url: String): Bitmap? {
        return try {
            val f = File(dir, Integer.toHexString(url.hashCode()) + ".jpg")
            if (!f.exists() || f.length() < 10_000) {
                if (!Net.download(url, f)) {
                    f.delete()
                    return null
                }
                trimCache()
            }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (t: Throwable) {
            null
        }
    }

    private fun trimCache() {
        val files = dir.listFiles { f -> f.name.endsWith(".jpg") } ?: return
        files.sortedByDescending { it.lastModified() }.drop(30).forEach { it.delete() }
    }
}
