package com.arch.tv

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextClock
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var grid: RecyclerView
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var dim: View
    private lateinit var weatherBox: View
    private lateinit var weatherMain: TextView
    private lateinit var weatherSub: TextView
    private lateinit var slideshow: Slideshow

    private val adapter = AppAdapter(
        onClick = { launchApp(it) },
        onLongClick = { showAppMenu(it) }
    )
    private val worker = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    private var allApps: List<AppItem> = emptyList()
    private var lastWeather: WeatherInfo? = null
    private var lastWeatherAt = 0L

    private val weatherTick = object : Runnable {
        override fun run() {
            refreshWeather()
            handler.postDelayed(this, WEATHER_EVERY_MS)
        }
    }

    // Refresh the app list whenever an app is installed or removed
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        dim = findViewById(R.id.dim)
        weatherBox = findViewById(R.id.weather)
        weatherMain = findViewById(R.id.weatherMain)
        weatherSub = findViewById(R.id.weatherSub)
        slideshow = Slideshow(this, findViewById(R.id.bgOld), findViewById(R.id.bgNew), prefs)

        grid.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        grid.adapter = adapter
        grid.itemAnimator = null

        findViewById<View>(R.id.settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        applySettings()
    }

    override fun onPause() {
        slideshow.stop()
        handler.removeCallbacks(weatherTick)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Home pressed while already here: jump back to the first app
        grid.scrollToPosition(0)
        grid.post { grid.getChildAt(0)?.requestFocus() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // A launcher should never close itself
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        slideshow.stop()
        worker.shutdown()
        net.shutdown()
        super.onDestroy()
    }

    // ---------- settings -> screen ----------

    private fun applySettings() {
        dim.alpha = prefs.dim / 100f

        val fmt = if (prefs.clock24) "HH:mm" else "h:mm"
        clock.format12Hour = fmt
        clock.format24Hour = fmt
        date.visibility = if (prefs.showDate) View.VISIBLE else View.GONE

        adapter.configure(
            sizeDp = when (prefs.iconSize) {
                0 -> 68
                2 -> 104
                else -> 86
            },
            labelsOnFocus = prefs.labelsOnFocus
        )
        applyAppList()

        if (prefs.natureBg) slideshow.start() else slideshow.stop(clear = true)

        handler.removeCallbacks(weatherTick)
        if (prefs.weatherOn) {
            if (lastWeather?.fahrenheit != prefs.fahrenheit) lastWeather = null
            lastWeather?.let { showWeather(it) }
            val age = System.currentTimeMillis() - lastWeatherAt
            val wait = if (lastWeather != null && age < WEATHER_MIN_GAP_MS) WEATHER_MIN_GAP_MS - age else 0L
            handler.postDelayed(weatherTick, wait)
        } else {
            weatherBox.visibility = View.GONE
        }
    }

    // ---------- apps ----------

    private fun loadApps() {
        worker.execute {
            val apps = AppRepo.queryAll(this)
            runOnUiThread {
                allApps = apps
                applyAppList()
            }
        }
    }

    private fun applyAppList() {
        val hidden = prefs.hidden
        val pinned = prefs.pinned
        val visible = allApps.filter { it.pkg !in hidden }
        val rest = visible.filter { it.pkg !in pinned }.let { list ->
            if (prefs.newestFirst) list.sortedByDescending { it.installed }
            else list.sortedBy { it.label.lowercase() }
        }
        val front = pinned.mapNotNull { p -> visible.firstOrNull { it.pkg == p } }
        if (adapter.submit(front + rest)) {
            grid.post { grid.getChildAt(0)?.requestFocus() }
        }
    }

    private fun launchApp(item: AppItem) {
        try {
            startActivity(item.launch)
        } catch (_: Exception) {
            // app vanished or can't be opened; ignore
        }
    }

    // Long-press an app: pin, hide, or open its info page
    private fun showAppMenu(item: AppItem) {
        val pinned = prefs.pinned
        val isPinned = item.pkg in pinned
        val options = arrayOf(
            if (isPinned) "Unpin from front" else "Pin to front",
            "Hide from home",
            "App info / uninstall"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        prefs.pinned = if (isPinned) pinned - item.pkg else pinned + item.pkg
                        applyAppList()
                    }
                    1 -> {
                        prefs.hidden = prefs.hidden + item.pkg
                        applyAppList()
                    }
                    2 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            .show()
    }

    // ---------- weather ----------

    private fun refreshWeather() {
        net.execute {
            val w = WeatherRepo.fetch(prefs)
            runOnUiThread {
                if (w != null && prefs.weatherOn) {
                    lastWeather = w
                    lastWeatherAt = System.currentTimeMillis()
                    showWeather(w)
                }
            }
        }
    }

    private fun showWeather(w: WeatherInfo) {
        weatherBox.visibility = View.VISIBLE
        weatherMain.text = "${w.emoji} ${w.temp}°"
        val place = if (w.city.isNotEmpty()) "${w.city} · " else ""
        weatherSub.text = "$place${w.desc} · H ${w.hi}°  L ${w.lo}°"
    }

    companion object {
        private const val WEATHER_EVERY_MS = 30 * 60 * 1000L
        private const val WEATHER_MIN_GAP_MS = 10 * 60 * 1000L
    }
}

class AppAdapter(
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()
    private var sizeDp = 86
    private var labelsOnFocus = false

    fun configure(sizeDp: Int, labelsOnFocus: Boolean) {
        if (this.sizeDp != sizeDp || this.labelsOnFocus != labelsOnFocus) {
            this.sizeDp = sizeDp
            this.labelsOnFocus = labelsOnFocus
            notifyDataSetChanged()
        }
    }

    /** Returns true if the set/order of apps changed (so the row was rebuilt). */
    fun submit(newItems: List<AppItem>): Boolean {
        val changed = newItems.map { it.pkg } != items.map { it.pkg }
        items = newItems
        if (changed) notifyDataSetChanged()
        return changed
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tile: FrameLayout = view.findViewById(R.id.tile)
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.15f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(130).start()
            if (labelsOnFocus) {
                view.findViewById<View>(R.id.label)
                    .animate().alpha(if (hasFocus) 1f else 0f).setDuration(130).start()
            }
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val px = (sizeDp * holder.itemView.resources.displayMetrics.density).toInt()
        holder.tile.layoutParams = holder.tile.layoutParams.apply { width = px; height = px }
        holder.label.layoutParams = holder.label.layoutParams.apply { width = px }
        holder.icon.setImageDrawable(item.icon)
        holder.label.text = item.label
        holder.label.alpha = if (labelsOnFocus && !holder.itemView.hasFocus()) 0f else 1f
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
    }

    override fun getItemCount() = items.size
}
